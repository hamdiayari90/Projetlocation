import 'package:flutter_web/material.dart';
import './views/app.dart';

void main() {
  runApp(App());
}
